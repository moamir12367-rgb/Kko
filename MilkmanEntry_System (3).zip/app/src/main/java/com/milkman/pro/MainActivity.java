package com.milkman.pro;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.telephony.SmsManager;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.CancellationSignal;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {
    static final int REQ_FILE = 1, REQ_SMS = 2, REQ_NOTIF = 3, REQ_STORAGE = 4;
    WebView web;
    ValueCallback<Uri[]> chooser;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Scheduler.createChannel(this);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return openOutside(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return openOutside(Uri.parse(url));
            }

            boolean openOutside(Uri uri) {
                if (uri.toString().startsWith("file:///android_asset/")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                return true; // wa.me, http(s) wagairah bahar khulenge
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    chooser = null;
                    return false;
                }
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
        Scheduler.scheduleAll(this);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooser = null;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        if (req == REQ_SMS) {
            boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            js("window.onSmsPermission && window.onSmsPermission(" + ok + ")");
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    void js(String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    void toast(String m) {
        runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show());
    }

    Uri saveMedia(String b64, String name, String mime, boolean image) throws Exception {
        byte[] data = Base64.decode(b64, Base64.DEFAULT);
        if (Build.VERSION.SDK_INT < 29) return saveLegacy(data, name, mime, image);
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        Uri coll;
        if (image) {
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MilkmanPRO");
            coll = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        } else {
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        }
        Uri u = getContentResolver().insert(coll, v);
        if (u == null) throw new Exception("insert failed");
        try (OutputStream o = getContentResolver().openOutputStream(u)) {
            o.write(data);
        }
        return u;
    }

    Uri saveLegacy(byte[] data, String name, String mime, boolean image) throws Exception {
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE));
            throw new Exception("Storage permission allow karo, phir dobara try karo");
        }
        java.io.File dir = image
                ? new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "MilkmanPRO")
                : Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        dir.mkdirs();
        java.io.File f = new java.io.File(dir, name);
        try (java.io.FileOutputStream o = new java.io.FileOutputStream(f)) {
            o.write(data);
        }
        if (image) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.DATA, f.getAbsolutePath());
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (u != null) return u;
        }
        return Uri.fromFile(f);
    }

    class Bridge {
        @JavascriptInterface
        public void scheduleReminders(String json) {
            getSharedPreferences("m", MODE_PRIVATE).edit().putString("rem", json).apply();
            Scheduler.scheduleAll(MainActivity.this);
        }

        @JavascriptInterface
        public void showNotification(String title, String body) {
            Scheduler.notify(MainActivity.this, title, body);
        }

        @JavascriptInterface
        public void saveFile(String b64, String name, String mime) {
            try {
                saveMedia(b64, name, (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime, false);
                toast("Saved in Downloads: " + name);
            } catch (Exception e) {
                toast("Save nahi hua: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void shareImage(String b64, String name, String caption) {
            try {
                String mime = name != null && name.toLowerCase().endsWith(".png") ? "image/png" : "image/jpeg";
                Uri u = saveMedia(b64, name, mime, true);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, u);
                if (caption != null && !caption.isEmpty()) i.putExtra(Intent.EXTRA_TEXT, caption);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent ch = Intent.createChooser(i, "Share bill");
                ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(ch);
            } catch (Exception e) {
                toast("Share nahi hua: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public boolean canBiometric() {
            if (Build.VERSION.SDK_INT < 28) return false;
            if (Build.VERSION.SDK_INT >= 30) {
                BiometricManager bm = getSystemService(BiometricManager.class);
                return bm != null && bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                        == BiometricManager.BIOMETRIC_SUCCESS;
            }
            if (Build.VERSION.SDK_INT >= 29) {
                BiometricManager bm = getSystemService(BiometricManager.class);
                return bm != null && bm.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
            }
            return getPackageManager().hasSystemFeature(PackageManager.FEATURE_FINGERPRINT);
        }

        @JavascriptInterface
        public void biometricAuth(String title, String sub) {
            if (Build.VERSION.SDK_INT < 28) { js("window.onBiometric && window.onBiometric(false,'Android 9+ chahiye')"); return; }
            runOnUiThread(() -> {
                try {
                    BiometricPrompt bp = new BiometricPrompt.Builder(MainActivity.this)
                            .setTitle(title == null ? "Unlock" : title)
                            .setSubtitle(sub == null ? "" : sub)
                            .setNegativeButton("Password use karo", getMainExecutor(), (d, w) ->
                                    js("window.onBiometric && window.onBiometric(false,'cancel')"))
                            .build();
                    bp.authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                            js("window.onBiometric && window.onBiometric(true,'')");
                        }

                        @Override
                        public void onAuthenticationError(int code, CharSequence msg) {
                            js("window.onBiometric && window.onBiometric(false," + JSONObject.quote(String.valueOf(msg)) + ")");
                        }
                    });
                } catch (Exception e) {
                    js("window.onBiometric && window.onBiometric(false," + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
                }
            });
        }

        @JavascriptInterface
        public boolean hasSmsPermission() {
            if (Build.VERSION.SDK_INT < 23) return true;
            return checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void requestSmsPermission() {
            if (Build.VERSION.SDK_INT < 23) { js("window.onSmsPermission && window.onSmsPermission(true)"); return; }
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQ_SMS));
        }

        @JavascriptInterface
        public void sendSms(String number, String text, String reqId) {
            final String action = "com.milkman.pro.SMS_SENT." + System.nanoTime();
            final BroadcastReceiver rx = new BroadcastReceiver() {
                @Override
                public void onReceive(Context c, Intent i) {
                    int code = getResultCode();
                    try { unregisterReceiver(this); } catch (Exception ignored) { }
                    js("window.onSmsSent && window.onSmsSent(" + JSONObject.quote(reqId) + ","
                            + (code == Activity.RESULT_OK) + "," + code + ")");
                }
            };
            try {
                IntentFilter f = new IntentFilter(action);
                if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED);
                else registerReceiver(rx, f);
                Intent in = new Intent(action).setPackage(getPackageName());
                PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 0, in,
                        PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                SmsManager sm = Build.VERSION.SDK_INT >= 31
                        ? getSystemService(SmsManager.class) : SmsManager.getDefault();
                ArrayList<String> parts = sm.divideMessage(text);
                ArrayList<PendingIntent> sent = new ArrayList<>();
                for (int k = 0; k < parts.size(); k++) sent.add(pi);
                sm.sendMultipartTextMessage(number, null, parts, sent, null);
            } catch (Exception e) {
                try { unregisterReceiver(rx); } catch (Exception ignored) { }
                js("window.onSmsSent && window.onSmsSent(" + JSONObject.quote(reqId) + ",false,-1)");
            }
        }
    }
}
